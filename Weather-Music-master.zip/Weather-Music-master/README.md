# Weather-Music
Tailored music playlist based users current weather
